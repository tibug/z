﻿IF OBJECT_ID(N'[__EFMigrationsHistory]') IS NULL
BEGIN
    CREATE TABLE [__EFMigrationsHistory] (
        [MigrationId] nvarchar(150) NOT NULL,
        [ProductVersion] nvarchar(32) NOT NULL,
        CONSTRAINT [PK___EFMigrationsHistory] PRIMARY KEY ([MigrationId])
    );
END;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20240215212756_init')
BEGIN
    CREATE TABLE [tblContacts] (
        [Id] int NOT NULL IDENTITY,
        [first_name] nvarchar(max) NOT NULL,
        [last_name] nvarchar(max) NOT NULL,
        [work_email] nvarchar(max) NOT NULL,
        [personal_email] nvarchar(max) NOT NULL,
        [company] nvarchar(max) NOT NULL,
        [domain] nvarchar(max) NULL,
        [job_title] nvarchar(max) NULL,
        [job_level] nvarchar(max) NULL,
        [job_department] nvarchar(max) NULL,
        [work_phone] nvarchar(max) NULL,
        [work_mobile] nvarchar(max) NULL,
        [work_dbn] nvarchar(max) NULL,
        [mobile] nvarchar(max) NULL,
        [alt_mobile] nvarchar(max) NULL,
        [branch_phone] nvarchar(max) NULL,
        [hq_phone] nvarchar(max) NULL,
        [street1] nvarchar(max) NULL,
        [street2] nvarchar(max) NULL,
        [city] nvarchar(max) NULL,
        [state] nvarchar(max) NULL,
        [zip] nvarchar(max) NULL,
        [country] nvarchar(max) NULL,
        [location_type] nvarchar(max) NULL,
        [company_revenue] nvarchar(max) NULL,
        [company_employee_count] nvarchar(max) NULL,
        [linkedin_url] nvarchar(max) NULL,
        [twitter_url] nvarchar(max) NULL,
        [company_linkedin_url] nvarchar(max) NULL,
        [naics_code] nvarchar(max) NULL,
        [sic_code] nvarchar(max) NULL,
        [company_sector] nvarchar(max) NULL,
        [company_industry] nvarchar(max) NULL,
        [keywords] nvarchar(max) NULL,
        CONSTRAINT [PK_tblContacts] PRIMARY KEY ([Id])
    );
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20240215212756_init')
BEGIN
    CREATE TABLE [tblUsers] (
        [Id] int NOT NULL IDENTITY,
        [Email] nvarchar(max) NOT NULL,
        [password] nvarchar(max) NOT NULL,
        [FirstName] nvarchar(max) NOT NULL,
        [LastName] nvarchar(max) NOT NULL,
        [ExportTodayLimit] int NOT NULL,
        [PerExportLimit] int NOT NULL,
        [isActive] bit NOT NULL,
        [isAdmin] bit NOT NULL,
        CONSTRAINT [PK_tblUsers] PRIMARY KEY ([Id])
    );
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20240215212756_init')
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240215212756_init', N'7.0.0');
END;
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20240220212315_chnage_tblcontact')
BEGIN
    DECLARE @var0 sysname;
    SELECT @var0 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[tblContacts]') AND [c].[name] = N'alt_mobile');
    IF @var0 IS NOT NULL EXEC(N'ALTER TABLE [tblContacts] DROP CONSTRAINT [' + @var0 + '];');
    ALTER TABLE [tblContacts] DROP COLUMN [alt_mobile];
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20240220212315_chnage_tblcontact')
BEGIN
    DECLARE @var1 sysname;
    SELECT @var1 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[tblContacts]') AND [c].[name] = N'branch_phone');
    IF @var1 IS NOT NULL EXEC(N'ALTER TABLE [tblContacts] DROP CONSTRAINT [' + @var1 + '];');
    ALTER TABLE [tblContacts] DROP COLUMN [branch_phone];
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20240220212315_chnage_tblcontact')
BEGIN
    DECLARE @var2 sysname;
    SELECT @var2 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[tblContacts]') AND [c].[name] = N'company_linkedin_url');
    IF @var2 IS NOT NULL EXEC(N'ALTER TABLE [tblContacts] DROP CONSTRAINT [' + @var2 + '];');
    ALTER TABLE [tblContacts] DROP COLUMN [company_linkedin_url];
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20240220212315_chnage_tblcontact')
BEGIN
    DECLARE @var3 sysname;
    SELECT @var3 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[tblContacts]') AND [c].[name] = N'hq_phone');
    IF @var3 IS NOT NULL EXEC(N'ALTER TABLE [tblContacts] DROP CONSTRAINT [' + @var3 + '];');
    ALTER TABLE [tblContacts] DROP COLUMN [hq_phone];
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20240220212315_chnage_tblcontact')
BEGIN
    DECLARE @var4 sysname;
    SELECT @var4 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[tblContacts]') AND [c].[name] = N'keywords');
    IF @var4 IS NOT NULL EXEC(N'ALTER TABLE [tblContacts] DROP CONSTRAINT [' + @var4 + '];');
    ALTER TABLE [tblContacts] DROP COLUMN [keywords];
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20240220212315_chnage_tblcontact')
BEGIN
    DECLARE @var5 sysname;
    SELECT @var5 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[tblContacts]') AND [c].[name] = N'location_type');
    IF @var5 IS NOT NULL EXEC(N'ALTER TABLE [tblContacts] DROP CONSTRAINT [' + @var5 + '];');
    ALTER TABLE [tblContacts] DROP COLUMN [location_type];
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20240220212315_chnage_tblcontact')
BEGIN
    DECLARE @var6 sysname;
    SELECT @var6 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[tblContacts]') AND [c].[name] = N'sic_code');
    IF @var6 IS NOT NULL EXEC(N'ALTER TABLE [tblContacts] DROP CONSTRAINT [' + @var6 + '];');
    ALTER TABLE [tblContacts] DROP COLUMN [sic_code];
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20240220212315_chnage_tblcontact')
BEGIN
    DECLARE @var7 sysname;
    SELECT @var7 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[tblContacts]') AND [c].[name] = N'street2');
    IF @var7 IS NOT NULL EXEC(N'ALTER TABLE [tblContacts] DROP CONSTRAINT [' + @var7 + '];');
    ALTER TABLE [tblContacts] DROP COLUMN [street2];
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20240220212315_chnage_tblcontact')
BEGIN
    DECLARE @var8 sysname;
    SELECT @var8 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[tblContacts]') AND [c].[name] = N'twitter_url');
    IF @var8 IS NOT NULL EXEC(N'ALTER TABLE [tblContacts] DROP CONSTRAINT [' + @var8 + '];');
    ALTER TABLE [tblContacts] DROP COLUMN [twitter_url];
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20240220212315_chnage_tblcontact')
BEGIN
    DECLARE @var9 sysname;
    SELECT @var9 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[tblContacts]') AND [c].[name] = N'work_dbn');
    IF @var9 IS NOT NULL EXEC(N'ALTER TABLE [tblContacts] DROP CONSTRAINT [' + @var9 + '];');
    ALTER TABLE [tblContacts] DROP COLUMN [work_dbn];
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20240220212315_chnage_tblcontact')
BEGIN
    DECLARE @var10 sysname;
    SELECT @var10 = [d].[name]
    FROM [sys].[default_constraints] [d]
    INNER JOIN [sys].[columns] [c] ON [d].[parent_column_id] = [c].[column_id] AND [d].[parent_object_id] = [c].[object_id]
    WHERE ([d].[parent_object_id] = OBJECT_ID(N'[tblContacts]') AND [c].[name] = N'work_mobile');
    IF @var10 IS NOT NULL EXEC(N'ALTER TABLE [tblContacts] DROP CONSTRAINT [' + @var10 + '];');
    ALTER TABLE [tblContacts] DROP COLUMN [work_mobile];
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20240220212315_chnage_tblcontact')
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240220212315_chnage_tblcontact', N'7.0.0');
END;
GO

COMMIT;
GO

BEGIN TRANSACTION;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20240316224948_LoggedInUserInfoTbl')
BEGIN
    CREATE TABLE [tblLoggedinUserInfo] (
        [Id] int NOT NULL IDENTITY,
        [Email] nvarchar(max) NOT NULL,
        [ExportTodayLimit] int NULL,
        [PerExportLimit] int NULL,
        CONSTRAINT [PK_tblLoggedinUserInfo] PRIMARY KEY ([Id])
    );
END;
GO

IF NOT EXISTS(SELECT * FROM [__EFMigrationsHistory] WHERE [MigrationId] = N'20240316224948_LoggedInUserInfoTbl')
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20240316224948_LoggedInUserInfoTbl', N'7.0.0');
END;
GO

COMMIT;
GO

