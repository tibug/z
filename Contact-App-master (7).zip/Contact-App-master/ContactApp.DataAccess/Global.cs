﻿global using ContactApp.Models.Dtos;
global using Dapper;
global using Microsoft.Data.SqlClient;
global using Microsoft.Extensions.Logging;
global using System.Data;