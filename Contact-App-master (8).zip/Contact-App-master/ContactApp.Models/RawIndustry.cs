﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContactApp.Models
{
    public class RawIndustry
    {
        public List<string>? headingjob1 { get; set; }
        public List<string>? headingjob2 { get; set; }
        public List<string>? headingjob3 { get; set; }
        public List<string>? headingjob4 { get; set; }
        public List<string>? headingjob5 { get; set; }
        public List<string>? headingjob6 { get; set; }
        public List<string>? headingjob7 { get; set; }
        public List<string>? headingjob8 { get; set; }
        public List<string>? headingjob9 { get; set; }
        public List<string>? headingjob10 { get; set; }
        public List<string>? headingjob11{ get; set; }
       
    

    }
}
