﻿using ContactApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContactApp.DataAccess.IRepository
{
    public interface IContact
    {
        Task<ResponseMessage> Save(Contacts users);
        Task<ResponseMessage> SaveRange(IEnumerable<Contacts> users);
        Task<ResponseMessage> Update(Contacts users);

        Task<IEnumerable<Users>> GetAll(CustomSearchUsers? searchData);
        Task<Contacts> Get(int id);
        Task<ResponseMessage> Delete(int id);
    }
}
