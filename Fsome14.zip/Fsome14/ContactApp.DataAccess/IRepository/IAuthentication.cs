﻿using ContactApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;

namespace ContactApp.DataAccess.IRepository
{
    public interface IAuthentication
    {
        Task<ResponseMessage> LoginUser(LoginViewModel data);
        Task<ResponseMessage> RegisterUser(Users data);
        Task<ResponseMessage> ChangePassword(ChangePasswordViewModel data);
        Task<ResponseMessage> SaveCode(VerifyEmailViewModel data);

        Task<ResponseMessage> CheckEmailVeirifyKey(string email,string key);
    }
}
