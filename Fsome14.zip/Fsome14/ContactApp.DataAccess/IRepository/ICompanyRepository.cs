﻿namespace ContactApp.DataAccess.IRepository;

public interface ICompanyRepository
{
    Task<CompanyProfileDto> GetCompanyProfileByCompanyIdAsync(long? companyId);
}
