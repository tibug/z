﻿using ContactApp.DataAccess.IRepository;
using ContactApp.DataAccess.Repository;
using ContactApp.Models;

using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.Design;
using System.Net.Mime;
using System.Security.Claims;
using System.Text;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace ContactApp.Web.Controllers
{
    public class LoginController : Controller
    {
        private readonly IAuthentication _authentication;
        //private readonly UserManager<Users> userManager;
       
        //private readonly HttpClient _httpClient;
        private readonly IConfiguration _config;

        public LoginController(IAuthentication authentication,
            
            //, UserManager<Users> _userManager,
           // IHttpClientFactory httpClientFactory, 
            IConfiguration config
            )
        {
            _authentication = authentication;
            
            // this.userManager = _userManager;

            // Get your named HttpClient that is preconfigured
          //this._httpClient = httpClientFactory.CreateClient("Mailgun");
          //  this._config = config;

        }
        public IActionResult Index()
        {
            //var userAuthenticate = Request.Cookies["userAuthenticate"];
            //if (!string.IsNullOrEmpty(userAuthenticate))
            //{
            //    return RedirectToAction("Index", "Home");
            //}

            //ClaimsPrincipal claimuser = HttpContext.User;
            //if (claimuser.Identity.IsAuthenticated)
            //{
            //    return RedirectToAction("Index", "Home");
            //}

            return View();
        }

        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            Response.Cookies.Delete("userAuthenticate");

            if (HttpContext.Request.Cookies["userCheck"] != null)
            {
                Response.Cookies.Delete("userCheck");

            }
            if (HttpContext.Request.Cookies["searchlimit"] != null)
            {

                Response.Cookies.Delete("searchlimit");
            }

            return RedirectToAction("Index", "Login");
        }


        public IActionResult Signup()
        {
            return View();
        }

    

        [HttpPost]
        public async Task<IActionResult> LoginUser([FromBody] LoginViewModel data)
        {
            if (!ModelState.IsValid)
            {
                return Ok(new { success = false, message = "Email and password are Required" });
            }
            var result = await _authentication.LoginUser(data);
            if (result.IsSuccess)
            {
                List<Claim> claims = new()
                {
                    new Claim(ClaimTypes.NameIdentifier,result.data.Email),
                    new Claim(ClaimTypes.Role,result.data.isAdmin?"admin":"user"),
                    new Claim(ClaimTypes.Name,result.data.FirstName),
                    new Claim(ClaimTypes.Email,result.data.Email),
                };

                ClaimsIdentity claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);

                AuthenticationProperties authprop = new()
                {
                    AllowRefresh = true,
                    IsPersistent = data.IsRemember,
                };
                await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(claimsIdentity), authprop);


                return Ok(new { success = true, message = result.Message });
            }

            return Ok(new { success = false, message = result.Message });

        }

        //public async Task<IActionResult> ChangePassword(string username)
        //{
        //    if (string.IsNullOrEmpty(username))
        //    {
        //        return RedirectToAction("VerifyEmail", "Login");
        //    }

        //    string[] tokens = username.Split("---");

        //    var result = await _authentication.CheckEmailVeirifyKey(tokens[0], tokens[1]);
        //    if (result.IsSuccess)
        //    {
        //        return View(new ChangePasswordViewModel { Email = tokens[0] });
        //    }
        //    else
        //    {
        //        return RedirectToAction("Index", "Login");
        //    }
        //  }

        //[HttpPost]
        //public async Task<IActionResult> ChangePassword(ChangePasswordViewModel model)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //         return Ok(new { success = false, message = "Email and password are Required" });
        //    }
        //    var result = await _authentication.ChangePassword(model);
        //    if (result.IsSuccess)
        //    {
        //        return Ok(new { success = true, message = result.Message });
        //    }

        //    return Ok(new { success = false, message = "Could not update password" });

        //}



        public async Task<IActionResult> ResetEmail()
        {
            ClaimsPrincipal claimuser = HttpContext.User;
            if (claimuser.Identity.IsAuthenticated)
            {
                return RedirectToAction("Index", "Home");
            }
            return null;
        }

        //public IActionResult VerifyEmail()
        //{
        //    return View();
        //}

        //[HttpPost]
        //public async Task<IActionResult> VerifyEmail(VerifyEmailViewModel model)
        //{
        //    if (ModelState.IsValid)
        //    {

        //        var dynId = Guid.NewGuid().ToString("N");
        //        var dynIdwithEmail= model.Email  + "---" + dynId;
                
        //        using MultipartFormDataContent form = new();

        //        // Local function keeps this code a bit clearer
        //        void SetFormParam(string key, string value) =>
        //        form.Add(new StringContent(value, Encoding.UTF8, MediaTypeNames.Text.Plain), key);

        //        SetFormParam("from", $"Test User <postmaster@{this._config.GetValue<string>("Mailgun:Domain")}>");
        //        SetFormParam("to", "ranasaleem6211@gmail.com");
        //        SetFormParam("subject", "Hello World!");
        //        SetFormParam("text", "My first transactional email!");
        //        SetFormParam("html", @"<html><body><p style=""color:blue;"">My first transactional email!</p>\n<a href=""https://localhost:7001/login/changepassword?username= " + dynIdwithEmail +  ">login</a></body></html>");

        //        var result = await this._httpClient.PostAsync(string.Empty, form);

        //        model.Code = dynId;
        //        var resCode = await _authentication.SaveCode(model);

        //        //TempData["SuccessMessage"] = "Reset";
        //        if (!result.IsSuccessStatusCode)
        //        {
        //            var expRes = new JsonResult(await result.Content.ReadAsStringAsync()).Value;
        //            ModelState.AddModelError("", expRes.ToString());
        //            return View(model);
        //            //return View();
        //        }


        //        TempData["SuccessMessage"] = "Reset link sent to your email. You should get an email soon!";
        //        return View(model);
        //    }
        //    return View(model);
        //}


        [HttpPost]
        public async Task<IActionResult> RegUser([FromBody] Users data)
        {
            if (!ModelState.IsValid)
            {
                return Ok(new { success = false, message = "Email and password are Required" });
            }

            data.searchlimit = "12";
            data.ExportTodayLimit = 100;
            data.PerExportLimit = 100;
            data.isActive = false;
            data.isAdmin = false;

            var result = await _authentication.RegisterUser(data);
            if (result.IsSuccess)
            {
                return Ok(new { success = true, message = result.Message });
            }

            return Ok(new { success = false, message = result.Message });

        }


    }
}
