﻿
using ContactApp.Models.Dtos;
using CsvHelper;
using System.ComponentModel;
using System.Globalization;
using System.Text.RegularExpressions;

namespace ContactApp.Web.Controllers;


public class PersonController : Controller
{
    private readonly ApplicationDbContext _db;
    private readonly INotyfService _notyfService;
    private readonly IContactRepository _contactRepository;
    private readonly ILookupRepository _lookupRepository;
    private readonly ICompanyRepository _companyRepository;
    private readonly ILogger<ContactFilterController> _logger;

    public PersonController(ApplicationDbContext db, INotyfService notyfService,
        ILogger<ContactFilterController> logger,
        IContactRepository contactRepository,
        ICompanyRepository companyRepository,
        ILookupRepository lookupRepository)
    {
        _db = db;
        _notyfService = notyfService;
        _logger = logger;
        _contactRepository = contactRepository;
        _companyRepository = companyRepository;
        _lookupRepository = lookupRepository;
    }

    [AllowAnonymous]
    [HttpGet]
    [Route("Person/{personName}/{Id:long}")]
    public async Task<IActionResult> Person(string personName, long Id)
    {

        var result = await _db.Contacts.Where(x => x.Id == Id).FirstOrDefaultAsync();

        var dbPersonName = Regex.Replace(result.Name, @"\s+", "");
        var perName = Regex.Replace(personName, @"-", "");
        perName = Regex.Replace(perName, @"\s+", "");


        if (result == null 
            || dbPersonName != perName)
        {
            return RedirectToAction("Index", "Login");
        }
        var companyRes = await _companyRepository.GetCompanyProfileByCompanyIdAsync(result.CompanyId);


        return View(new PersonPageViewModel { ContactName=result.Name,
            Email = result.Email,
            Phone = result.Phone,
            WorkPhone = result.WorkPhone,
            LeadTitle  = result.LeadTitle,
            PastCompanies = result.PastCompanies,
            Skills = result.Skills,

            CompanyName =companyRes.CompanyName,
            CompanyDescription=companyRes.CompanyDescription,
            CompanyAddress = companyRes.CompanyLocationText,
            CompanyPhone = companyRes.CompanyPhoneNumbers,
            CompanySize= companyRes.CompanySize,
            CompanyWebsite= companyRes.CompanyWebsite,
        });
    }


}
