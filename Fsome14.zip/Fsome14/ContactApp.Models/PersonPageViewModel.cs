﻿using System.ComponentModel.DataAnnotations;

namespace ContactApp.Models
{
    public class PersonPageViewModel
    {
        
        

        public string? ContactName { get; set; }
        public string? Email { get; set; }
        public string? Phone { get; set; }
        public string? WorkPhone { get; set; }
        public string? LeadTitle { get; set; }
        public string? PastCompanies { get; set; }
        public string? Skills { get; set; }


        public string CompanyName { get; set; }
        public string? CompanyDescription { get; set; }
        public string? CompanyAddress { get; set; }
        public string? CompanyPhone { get; set; }
        public string? CompanySize { get; set; }
        public string CompanyWebsite { get; set; }
    }
}
