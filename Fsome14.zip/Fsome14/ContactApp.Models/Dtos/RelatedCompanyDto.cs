﻿namespace ContactApp.Models.Dtos;

public class RelatedCompanyDto
{
    public int CompanyId { get; set; }
    public string CompanyName { get; set; }
    public string CompanyProfileImageUrl { get; set; }
}
