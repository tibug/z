﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContactApp.Models
{
    public class RawCompanyIndustry
    {
        public List<string>? heading1 { get; set; }
        public List<string>? heading2 { get; set; }
        public List<string>? heading3 { get; set; }
        public List<string>? heading4 { get; set; }
        public List<string>? heading5 { get; set; }
        public List<string>? heading6 { get; set; }
        public List<string>? heading7 { get; set; }
        public List<string>? heading8 { get; set; }
        public List<string>? heading9 { get; set; }
        public List<string>? heading10 { get; set; }
        public List<string>? heading11 { get; set; }
        public List<string>? heading12 { get; set; }
        public List<string>? heading13 { get; set; }
        public List<string>? heading14 { get; set; }
        public List<string>? heading15 { get; set; }
        public List<string>? heading16 { get; set; }
        public List<string>? heading17 { get; set; }
        public List<string>? heading18 { get; set; }

        public List<string>? heading19 { get; set; }
        public List<string>? heading20 { get; set; }
        public List<string>? heading21 { get; set; }
        public List<string>? heading22 { get; set; }

        public List<string>? heading23 { get; set; }

        public List<string>? heading24 { get; set; }

    }
}
