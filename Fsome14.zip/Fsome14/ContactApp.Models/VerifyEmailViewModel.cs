﻿using System.ComponentModel.DataAnnotations;

namespace ContactApp.Models
{
    public class VerifyEmailViewModel
    {
        [Required(ErrorMessage = "Email is required.")]
        [EmailAddress]
        public string Email { get; set; }

        public string? Code { get; set; }
        public string? Message { get; set; }
    }
}
